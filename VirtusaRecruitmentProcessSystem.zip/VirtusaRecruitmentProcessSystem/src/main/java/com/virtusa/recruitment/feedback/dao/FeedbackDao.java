package com.virtusa.recruitment.feedback.dao;

import java.util.List;

import com.virtusa.recruitment.feedback.model.Feedback;

public interface FeedbackDao {
	public void add(Feedback feedback);
	public void update(Feedback feedback);
	public Feedback view(String feedbackId);
	public List<Feedback> getAllFeedbacks();
	public void delete(String feedbackId);
}
