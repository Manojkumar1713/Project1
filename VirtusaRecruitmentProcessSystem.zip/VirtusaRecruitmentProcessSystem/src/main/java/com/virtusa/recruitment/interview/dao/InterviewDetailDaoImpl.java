
package com.virtusa.recruitment.interview.dao;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.virtusa.recruitment.interview.model.InterviewDetail;
import com.virtusa.recruitment.job.model.Jobs;
import com.virtusa.recruitment.outercandidate.model.Candidate;
@Repository
public class InterviewDetailDaoImpl implements InterviewDetailDao {


	public void addDetails(InterviewDetail interview) {

		Session session=new Configuration().addAnnotatedClass(InterviewDetail.class).configure().buildSessionFactory().openSession();
		session.beginTransaction();
		session.save(interview);
		session.getTransaction().commit();
		session.close();

	}

	public void updateStatusInterview(InterviewDetail interview) {
		Session session=new Configuration().addAnnotatedClass(InterviewDetail.class).configure().buildSessionFactory().openSession();
		session.beginTransaction();
		session.update(interview);
		session.getTransaction().commit();
		session.close();		

	}

	public InterviewDetail findById(int employeeId) {
		Session session=new Configuration().addAnnotatedClass(InterviewDetail.class).configure().buildSessionFactory().openSession();
		int id= Integer.valueOf(employeeId);
		InterviewDetail interview=session.get(InterviewDetail.class, id);

		return interview;
	}

	public List<InterviewDetail> getall() {
		Session session=new Configuration().addAnnotatedClass(InterviewDetail.class).configure().buildSessionFactory().openSession();
		Query q=session.createQuery("from InterviewDetail");
		List l = q.getResultList();
		return l;
	}

	public void deleteById(String interviewId) {
		Session session=new Configuration().addAnnotatedClass(InterviewDetail.class).configure().buildSessionFactory().openSession();
		session.beginTransaction();
		int id=Integer.parseInt(interviewId);
		InterviewDetail interviewDetail = (InterviewDetail) session.get(InterviewDetail.class, id);
		session.delete(interviewDetail);
		session.getTransaction().commit();
		session.close();
	}
	public String checkApplication(int candidate_id,int job_id) {

		Session SESSION = new Configuration().addAnnotatedClass(InterviewDetail.class).configure().buildSessionFactory().openSession();
		Query q = SESSION.createQuery("select status from InterviewDetail where job_job_id=:un and candidate_candidateid=:cn");
		q.setParameter("un", job_id);
		q.setParameter("cn", candidate_id);
		List<String> l = q.getResultList();
		String status = l.get(0);
		return status;
	}
public List<InterviewDetail> getStatus(int id) {
		
		Session s = new Configuration().addAnnotatedClass(InterviewDetail.class).configure().buildSessionFactory().openSession();
		Query q = s.createQuery("from InterviewDetail where candidate_candidateId = :id");
		q.setParameter("id", id);
		List<InterviewDetail> list = q.getResultList();
		return list;
	}

public List<Jobs> getJobId(int id) {
	
	Session s = new Configuration().addAnnotatedClass(InterviewDetail.class).configure().buildSessionFactory().openSession();
	Query q = s.createQuery("select job from InterviewDetail where candidate_candidateId = :id");
	q.setParameter("id", id);
	List<Jobs> list = q.getResultList();
	return list;
}
//for interview jobs and candidate
public List<InterviewDetail> getallcandjob() {
	Session session=new Configuration().addAnnotatedClass(InterviewDetail.class).configure().buildSessionFactory().openSession();
	Query q=session.createQuery("from InterviewDetail");
	List l = q.getResultList();
	
	return l;
}
/* fetching candidate details by id*/
public List<Integer> findCandidateById(int Id)
{
	Session s = new Configuration().addAnnotatedClass(InterviewDetail.class).configure().buildSessionFactory().openSession();
	Query q = s.createSQLQuery("select candidate_candidateId from InterviewDetail where job_job_id=:Id");
	q.setParameter("Id", Id);
	List l=q.getResultList();
	
	return l;

}
public InterviewDetail getobj(int cid,int jid)
{
	Session s = new Configuration().addAnnotatedClass(InterviewDetail.class).configure().buildSessionFactory().openSession();
	Query q = s.createSQLQuery("select interviewId from InterviewDetail where job_job_id=:Id and candidate_candidateId=:i");
	q.setParameter("Id", jid);
	q.setParameter("i", cid);
	List l = q.getResultList();
	int x=(Integer) l.get(0);
	InterviewDetail  id = s.get(InterviewDetail.class, x);
	return id;
}
}
