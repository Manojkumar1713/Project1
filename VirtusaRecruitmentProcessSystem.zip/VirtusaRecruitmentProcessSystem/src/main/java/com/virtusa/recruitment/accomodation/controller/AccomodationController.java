package com.virtusa.recruitment.accomodation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.recruitment.accomodation.dao.AccomodationDao;
import com.virtusa.recruitment.accomodation.model.AccomodationDetail;


@Controller
public class AccomodationController {


	@Autowired
	AccomodationDao accomodationdao;

	@RequestMapping(value="addaccomodation",method=RequestMethod.GET)
	public ModelAndView getaccmodation()
	{
		return new ModelAndView("addaccomodation","addacc",new AccomodationDetail());
	}
	@RequestMapping(value="addaccomodation",method=RequestMethod.POST)
	public ModelAndView setaccomodation(@ModelAttribute("add") AccomodationDetail accomodationdetail)
	{

		accomodationdao.addAccomodation(accomodationdetail);
		List<AccomodationDetail> accomodationList = accomodationdao.viewAccomodation();
		ModelAndView mav = new ModelAndView("viewaccomodation");
		mav.addObject("list",accomodationList);
		return mav;

	}



	@RequestMapping(value="viewaccomodation")
	public ModelAndView viewlist()
	{
		List<AccomodationDetail> accomodationList = accomodationdao.viewAccomodation();
		ModelAndView mav = new ModelAndView("viewaccomodation");
		mav.addObject("list",accomodationList);
		return mav;
	}




	@RequestMapping(value="deleteaccomodation",method=RequestMethod.GET)
	public ModelAndView getdeleteId(@RequestParam(value="deleteid") String id) {

		int aid = Integer.parseInt(id);
		accomodationdao.deleteById(aid);
		List list = accomodationdao.viewAccomodation();
		ModelAndView mv = new ModelAndView("viewaccomodation");
		mv.addObject("list", list);

		return mv;
	}
	@RequestMapping(value="book")
	public String view() {
		return "bookacc";
	}
	@RequestMapping(value="viewaccomodationuser")
	public ModelAndView viewaccmodationtouser()
	{
		List<AccomodationDetail> accomodationList = accomodationdao.viewAccomodation();
		ModelAndView mav = new ModelAndView("bookaccomodation");
		mav.addObject("list",accomodationList);
		return mav;
	}

}



