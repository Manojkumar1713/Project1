package com.virtusa.recruitment.job.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.virtusa.recruitment.job.model.Jobs;
@Repository
public class JobsDaoImpl implements JobsDao{

	public void insertJob(Jobs job) {
	Session SESSION = new Configuration().addAnnotatedClass(Jobs.class).configure().buildSessionFactory().openSession();
	SESSION.beginTransaction();
	SESSION.save(job);
	SESSION.getTransaction().commit();
	SESSION.close();
		
	}

	public List<Jobs> getJoblist() {
		Session SESSION = new Configuration().addAnnotatedClass(Jobs.class).configure().buildSessionFactory().openSession();
		Query q = SESSION.createQuery("from Jobs");
		List l= q.getResultList();
		
		
		return l;
	}

	public void deleteById(String job_id) {
		
		Session session = new Configuration().addAnnotatedClass(Jobs.class).configure().buildSessionFactory().openSession();
		int a = Integer.valueOf(job_id);
		session.beginTransaction();
		Jobs job = (Jobs)session.get(Jobs.class, a);
		session.delete(job);
		session.getTransaction().commit();
		session.close();
	}
	
	public void update(Jobs job) {
		Session SESSION = new Configuration().addAnnotatedClass(Jobs.class).configure().buildSessionFactory().openSession();
		SESSION.beginTransaction();
		SESSION.update(job);
		SESSION.getTransaction().commit();
		SESSION.close();
	}

	public Jobs findById(String job_id) {
		Session SESSION = new Configuration().addAnnotatedClass(Jobs.class).configure().buildSessionFactory().openSession();
		int id = Integer.valueOf(job_id);
		Jobs job = SESSION.get(Jobs.class, id);		
		return job;
	}
	public List<Jobs> getJob() {
		Session session = new Configuration().addAnnotatedClass(Jobs.class).configure().buildSessionFactory().openSession();
		session.beginTransaction();
		Query q=session.createQuery("from Jobs where jobStatus=0");
		List<Jobs> jobs = q.getResultList();
		session.getTransaction().commit();
		session.close();
		return jobs;
	}
	public List<Jobs> getTJob() {
		Session session = new Configuration().addAnnotatedClass(Jobs.class).configure().buildSessionFactory().openSession();
		session.beginTransaction();
		Query q=session.createQuery("from Jobs where tstatus=0");
		List<Jobs> jobs = q.getResultList();
		session.getTransaction().commit();
		session.close();
		return jobs;
	}
	public void updatejob(int jobid)
	{
Session session = new Configuration().addAnnotatedClass(Jobs.class).configure().buildSessionFactory().openSession();
		
		session.beginTransaction();
		Query query=session.createQuery("update Jobs set jobStatus=1 where job_id=:jobid");
		query.setParameter("jobid", jobid);
		query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}
	public void updateTjob(int jobid)
	{
Session session = new Configuration().addAnnotatedClass(Jobs.class).configure().buildSessionFactory().openSession();
		
		session.beginTransaction();
		Query query=session.createQuery("update Jobs set tstatus=1 where job_id=:jobid");
		query.setParameter("jobid", jobid);
		query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}

}

