
package com.virtusa.recruitment.job.controller;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.recruitment.interview.dao.InterviewDetailDao;
import com.virtusa.recruitment.job.dao.JobsDaoImpl;
import com.virtusa.recruitment.job.model.Jobs;
import com.virtusa.recruitment.outercandidate.dao.OuterCandidateDaoImpl;
import com.virtusa.recruitment.outercandidate.model.Candidate;



@Controller
public class JobController {
	@Autowired
    public JobsDaoImpl jobdao;
	@Autowired
	private OuterCandidateDaoImpl outerCandidate ;
	@Autowired
	public InterviewDetailDao interviewdetaildao;
	
	
//	Set<String> techList = new HashSet<String>();
//	@RequestMapping(value="tech",method=RequestMethod.POST)
//	public String technologies(@ModelAttribute("tech") String tech) {
//		techList.add(tech);
//		return "jobform";
//	}
	
	
	
	@RequestMapping(value="jobs", method=RequestMethod.GET)
	public ModelAndView getinsert() {
		
		return new ModelAndView("jobform","job",new Jobs());
	}
	
	@RequestMapping(value="jobs", method=RequestMethod.POST)
	public ModelAndView setInsert(@ModelAttribute("jobs") Jobs job)
	{
	//	job.setTech(techList);
		jobdao.insertJob(job);
		List<Jobs> jobList =jobdao.getJoblist();
		ModelAndView view = new ModelAndView("view");
		view.addObject("list",jobList);
		
		return view;
	}
	@RequestMapping(value="view")
	public ModelAndView viewAll()
	{
		List<Jobs> jobList =jobdao.getJoblist();
		ModelAndView view = new ModelAndView("view");
		view.addObject("list",jobList);
		
		return view;
	}
	@RequestMapping(value="delete", method=RequestMethod.GET)
	public ModelAndView delete(@RequestParam(value="id") String id) {
		
		
		jobdao.deleteById(id);

		List<Jobs> jobList =jobdao.getJoblist();
		ModelAndView view = new ModelAndView("view");
		view.addObject("list",jobList);
		
		return view;
	}
	@RequestMapping(value="update", method=RequestMethod.GET)
	public ModelAndView update(@RequestParam(value="id") String id){
		Jobs job = jobdao.findById(id);
		//System.out.println(job.getCategory());
		return new ModelAndView("edit","update",job);
	}
	@RequestMapping(value="update",method=RequestMethod.POST)
	public ModelAndView updation(@ModelAttribute("update") Jobs job)
	{
		jobdao.update(job);
		List<Jobs> jobList =jobdao.getJoblist();
		ModelAndView view = new ModelAndView("view");
		view.addObject("list",jobList);
		
		return view;
	}
	@RequestMapping(value="applyjob")
	public ModelAndView viewjobs(@RequestParam("user") String user,HttpServletRequest req) {
		
		Candidate cand = outerCandidate.findById(user);
		int candidateId = cand.getCandidateId();
		List<Jobs> candJobs = interviewdetaildao.getJobId(candidateId);
		List<Jobs> jobList =jobdao.getJoblist();
		ModelAndView view = new ModelAndView("viewjobs");
		
		req.setAttribute("list", jobList);
		req.setAttribute("candjob", candJobs);
		
		
		
		return view;
	}
}
