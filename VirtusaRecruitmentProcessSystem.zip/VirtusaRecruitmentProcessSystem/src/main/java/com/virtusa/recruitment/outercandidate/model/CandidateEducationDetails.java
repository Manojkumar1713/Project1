package com.virtusa.recruitment.outercandidate.model;

import javax.persistence.Embeddable;

@Embeddable
public class CandidateEducationDetails {
	private String degree;
	private String department;
	private String collegeName;
	private long percentage;
	
	public CandidateEducationDetails() {
		super();
	}
	public CandidateEducationDetails(String degree, String department, String collegeName, long percentage) {
		super();
		this.degree = degree;
		this.department = department;
		this.collegeName = collegeName;
		this.percentage = percentage;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	public long getPercentage() {
		return percentage;
	}
	public void setPercentage(long percentage) {
		this.percentage = percentage;
	}
	

}
