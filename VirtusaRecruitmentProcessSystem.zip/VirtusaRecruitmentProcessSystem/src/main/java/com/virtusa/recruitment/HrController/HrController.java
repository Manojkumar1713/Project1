package com.virtusa.recruitment.HrController;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.recruitment.hR.Hr;
import com.virtusa.recruitment.hRdao.DaoImpl;
import com.virtusa.recruitment.interview.dao.InterviewDetailDaoImpl;
import com.virtusa.recruitment.job.dao.JobsDaoImpl;
import com.virtusa.recruitment.job.model.Jobs;
import com.virtusa.recruitment.outercandidate.dao.OuterCandidateDaoImpl;
import com.virtusa.recruitment.outercandidate.model.Candidate;


@Controller
public class HrController {
	
	@Autowired
	DaoImpl daiImpl;
	@Autowired
	JobsDaoImpl jobsdaoimpl;
	 @Autowired
	    InterviewDetailDaoImpl interviewdetaildaoimpl;
	    @Autowired
	    OuterCandidateDaoImpl outercandidateimpl;
	  /*  @Autowired
		TechnologyDaoImpl technologydaoimpl;*/
	
	@RequestMapping(value="Hrs",method=RequestMethod.GET)
	public ModelAndView addhr(@ModelAttribute("hrdata") Hr hr)
	{
		return new ModelAndView("Hr","command",new Hr());
	}
	
	@RequestMapping(value="Hrs",method=RequestMethod.POST)
	public ModelAndView addHr(@ModelAttribute("hrdata") Hr hr)
	{
		daiImpl.add(hr);
		ModelAndView model=new ModelAndView("adminhome");
		return model;
	}
	@RequestMapping("Viewhrs")
	public ModelAndView viewhr()
	{
		List<Hr> hrslist=daiImpl.view();
		ModelAndView model=new ModelAndView("ViewHrs");
		model.addObject("hrs",hrslist);
		model.addObject("hr1",hrslist);
		return model;
	}
	

	@RequestMapping(value="mains")
	public ModelAndView viewjobs() {
		List<Jobs> jobList =jobsdaoimpl.getJob();
		List<Hr> hrslist=daiImpl.viewAllHrs();
		ModelAndView model = new ModelAndView("mainPage");
		model.addObject("list",jobList);
		model.addObject("hrs",hrslist);
		return model;
		
	}
	
	@RequestMapping(value="updation")
	public ModelAndView updateHr(@RequestParam("hrname") int hrname,@RequestParam("jobid") int id)
	{
		Hr hr = daiImpl.find(hrname);
		hr.setJob(id);
		daiImpl.updateHR(hr);
		daiImpl.update(hrname);
		jobsdaoimpl.updatejob(id);
		List<Jobs> jobList =jobsdaoimpl.getJob();
		List<Hr> hrslist=daiImpl.viewAllHrs();
		ModelAndView model = new ModelAndView("mainPage");
		model.addObject("list",jobList);
		model.addObject("hrs",hrslist);
		return model;
	}
	
	@RequestMapping(value="vicandidates",method=RequestMethod.GET)
	public ModelAndView getdata(@RequestParam("id") int id)
	{
	      
		List<Integer> candIds = interviewdetaildaoimpl.findCandidateById(id);
		List<Candidate> jobcand = new ArrayList<Candidate>();
		
		for(int i=0;i<candIds.size();i++)
	    {
			Candidate cand = outercandidateimpl.Candfindbyid(candIds.get(i)); 
			jobcand.add(cand);
		}
		String ids= String.valueOf(id);
		Jobs job = jobsdaoimpl.findById(ids);
		ModelAndView mv = new ModelAndView("viewlistjchr");
		//List list=technologydaoimpl.viewall();
		//mv.addObject("tech",list);
		mv.addObject("jobcandlist",jobcand);
		mv.addObject("job",job);
		return mv;
	}
	
}
