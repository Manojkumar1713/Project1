package com.virtusa.recruitment.outercandidate.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.virtusa.recruitment.job.model.Jobs;
import com.virtusa.recruitment.outercandidate.model.Candidate;
@Repository
public class OuterCandidateDaoImpl implements OuterCandidateDao {

	public void addOuterCandidate(Candidate outercandidate) {
		
		Session session = new Configuration().addAnnotatedClass(Candidate.class).configure().buildSessionFactory().openSession();
		session.beginTransaction();
		session.save(outercandidate);
		session.getTransaction().commit();
		session.close();
		
	}
	public List<Candidate> getCandidatelist() {
		Session SESSION = new Configuration().addAnnotatedClass(Candidate.class).configure().buildSessionFactory().openSession();
		Query q = SESSION.createQuery("from Candidate");
		List l= q.getResultList();
		return l;
	}
	public void deleteById(int candidate_id) {
		
		Session session = new Configuration().addAnnotatedClass(Candidate.class).configure().buildSessionFactory().openSession();
		
		session.beginTransaction();
		Candidate outercandidate = (Candidate)session.get(Candidate.class, candidate_id);
		session.delete(outercandidate);
		session.getTransaction().commit();
		session.close();
	}
	
	public Candidate findById(String candidate_id) {
		Session SESSION = new Configuration().addAnnotatedClass(Candidate.class).configure().buildSessionFactory().openSession();
		Query q = SESSION.createQuery("select candidateId from Candidate where emailId=:un");
		q.setParameter("un", candidate_id);
		List<Integer> l = q.getResultList();
		int i = (int) l.get(0);
		Candidate outercandidate = SESSION.get(Candidate.class,i);		
		l.clear();
		return outercandidate;
	}
	public void updateOuterCandidate(Candidate outercandidate) {
		Session SESSION = new Configuration().addAnnotatedClass(Candidate.class).configure().buildSessionFactory().openSession();
		SESSION.beginTransaction();
		SESSION.update(outercandidate);
		SESSION.getTransaction().commit();
		SESSION.close();
		
	}
	public List<Candidate> viewUser(String candidate_id) {
		Session SESSION = new Configuration().addAnnotatedClass(Candidate.class).configure().buildSessionFactory().openSession();
		Query q = SESSION.createQuery("from Candidate where emailId=:un");
		q.setParameter("un", candidate_id);
		List<Candidate> l = q.getResultList();
		return l;
	}
	public Candidate Candfindbyid(int id)
	{
		Session SESSION = new Configuration().addAnnotatedClass(Candidate.class).configure().buildSessionFactory().openSession();
		Candidate cand = SESSION.get(Candidate.class, id);		
		return cand;
	}

}
