package com.virtusa.recruitment.outercandidate.model;

import javax.persistence.Embeddable;

@Embeddable
public class CandidateExperience {
 
	private int expYears;
	private String technology;
	private String domain;
	private String companyName;
	private String designation;
	public CandidateExperience() {
		super();
	}
	
	public CandidateExperience(int expYears, String technology, String domain, String companyName, String designation) {
		super();
		this.expYears = expYears;
		this.technology = technology;
		this.domain = domain;
		this.companyName = companyName;
		this.designation = designation;
	}

	public int getExpYears() {
		return expYears;
	}
	public void setExpYears(int expYears) {
		this.expYears = expYears;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	
}
