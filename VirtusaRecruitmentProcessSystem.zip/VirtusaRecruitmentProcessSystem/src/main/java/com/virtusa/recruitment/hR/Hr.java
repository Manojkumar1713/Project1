package com.virtusa.recruitment.hR;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;




@Entity
public class Hr {

	@Id
	@Column(unique=true)
	private int hrId;
	private String name;
	private String emailId;
	private String password;
	private String designation;
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	private int status;
	
	private int job;
	
	public int getJob() {
		return job;
	}
	public void setJob(int job) {
		this.job = job;
	}
	public int getHrId() {
		return hrId;
	}
	public void setHrId(int hrId) {
		this.hrId = hrId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public Hr(int hrId, String name, String emailId, String password, int status,String designation) {
		super();
		this.designation=designation;
		this.hrId = hrId;
		this.name = name;
		this.emailId = emailId;
		this.password = password;
		this.status = status;
	}
	public Hr() {
		super();

	}
	@Override
	public String toString() {
		return "Hr [hrId=" + hrId + ", name=" + name + ", emailId=" + emailId + ", password=" + password + ", status="
				+ status + "]";
	}
	
}
