package com.virtusa.recruitment.technology.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Technology {
    @Id
   @GeneratedValue(strategy=GenerationType.AUTO)
	private int technologyId;
    private String techonoglyName;
	public Technology() {
		super();
	}


	public Technology(int technologyId, String techonoglyName) {
		super();
		this.technologyId = technologyId;
		this.techonoglyName = techonoglyName;
	}


	public int getTechnologyId() {
		return technologyId;
	}


	public void setTechnologyId(int technologyId) {
		this.technologyId = technologyId;
	}


	public String getTechonoglyName() {
		return techonoglyName;
	}
	public void setTechonoglyName(String techonoglyName) {
		this.techonoglyName = techonoglyName;
	}
     


 
}
