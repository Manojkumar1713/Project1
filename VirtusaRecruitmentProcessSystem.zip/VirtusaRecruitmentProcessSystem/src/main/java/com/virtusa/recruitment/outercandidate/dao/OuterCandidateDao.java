package com.virtusa.recruitment.outercandidate.dao;

import java.util.List;

import com.virtusa.recruitment.outercandidate.model.Candidate;

public interface OuterCandidateDao {
	
	public void addOuterCandidate(Candidate outercandidate);
    public void updateOuterCandidate(Candidate outercandidate);
    public List<Candidate> getCandidatelist();
	public Candidate findById (String candidate_id);
	public void deleteById(int candidate_id);
	public List<Candidate> viewUser(String candidate_id);
}
