package com.virtusa.recruitment.job.model;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.virtusa.recruitment.interview.model.InterviewDetail;
import com.virtusa.recruitment.outercandidate.model.Candidate;


@Entity
public class Jobs {

@Id
@GeneratedValue(strategy=GenerationType.TABLE)
	private int job_id;
	private String category;
	private String job_description;
	private int experience;
	private String domain;
	private String location;
	private int vacancy;
//	@OneToMany(cascade=CascadeType.MERGE,mappedBy="candidateId")
//	private List<Candidate> candidate;
	private String temp;
	private int jobStatus;
	private int tstatus;
public Jobs(int job_id, String category, String job_description, int experience, String domain, String location,
			int vacancy, String temp, int jobStatus, int tstatus) {
		super();
		this.job_id = job_id;
		this.category = category;
		this.job_description = job_description;
		this.experience = experience;
		this.domain = domain;
		this.location = location;
		this.vacancy = vacancy;
	//	this.candidate = candidate;
		this.temp = temp;
		this.jobStatus = jobStatus;
		this.tstatus = tstatus;
	}

	public int getJobStatus() {
		return jobStatus;
	}
	public void setJobStatus(int jobStatus) {
		this.jobStatus = jobStatus;
	}
	
	public String getTemp() {
		return temp;
	}
	public void setTemp(String temp) {
		this.temp = temp;
	}
	public int getVacancy() {
		return vacancy;
	}
	
//	public List<Candidate> getCandidate() {
//		return candidate;
//	}
//	public void setCandidate(List<Candidate> candidate) {
//		this.candidate = candidate;
//	}
	
	
	public void setVacancy(int vacancy) {
		this.vacancy = vacancy;
	}
	public int getJob_id() {
		return job_id;
	}
	public void setJob_id(int job_id) {
		this.job_id = job_id;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getJob_description() {
		return job_description;
	}
	public void setJob_description(String job_description) {
		this.job_description = job_description;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	public int getTstatus() {
		return tstatus;
	}
	public void setTstatus(int tstatus) {
		this.tstatus = tstatus;
	}
	public Jobs() {
		super();
	
	}
//	public String getTech() {
//		return technologies;
//	}
//	public void setTech(String tech) {
//		this.technologies = tech;
//	}


	}
	
	
	



