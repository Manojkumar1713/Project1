package com.virtusa.recruitment.interview.controller;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.recruitment.interview.dao.InterviewDetailDao;
import com.virtusa.recruitment.interview.model.InterviewDetail;
import com.virtusa.recruitment.job.dao.JobsDaoImpl;
import com.virtusa.recruitment.job.model.Jobs;
import com.virtusa.recruitment.outercandidate.dao.OuterCandidateDaoImpl;
import com.virtusa.recruitment.outercandidate.model.Candidate;

@Controller
public class AdminController {
	@Autowired
	public InterviewDetailDao interviewdetaildao;
	@Autowired
	private OuterCandidateDaoImpl outerCandidate ;
	@Autowired
    public JobsDaoImpl jobdao;

	List<Candidate> candidateList = new ArrayList<Candidate>();
	
	
	 @RequestMapping(value="viewall")
	public ModelAndView viewall()
	{
		List<InterviewDetail> interviewlist = interviewdetaildao.getall();
		ModelAndView mav =new ModelAndView("View");
		mav.addObject("list",interviewlist);
		return mav;
		
	}
    @RequestMapping(value="deletejob",method=RequestMethod.GET)
	 public ModelAndView delete(@RequestParam(value="id") String id)
	 {
		 interviewdetaildao.deleteById(id);
		 List<InterviewDetail> interviewList = interviewdetaildao.getall();
		 ModelAndView mav =new ModelAndView("View");
			mav.addObject("list",interviewList);
			return mav;
	 }
	 @RequestMapping(value="edit",method=RequestMethod.GET)
public ModelAndView update(@RequestParam(value="id") String id)
	{
		 int uid=Integer.parseInt(id);
	 InterviewDetail interviewDetail = interviewdetaildao.findById(uid);
		 return new ModelAndView("editform","update",interviewDetail);
	}
   
	 
	 @RequestMapping(value="edit",method=RequestMethod.POST)
	 public ModelAndView updatation(@ModelAttribute("update") InterviewDetail interview)
	 {
		 interviewdetaildao.updateStatusInterview(interview);
		 List<InterviewDetail> interviewlist = interviewdetaildao.getall();
			ModelAndView mav =new ModelAndView("View");
			mav.addObject("list",interviewlist);
			return mav;
			
	 }
	 @RequestMapping(value="apply",method=RequestMethod.GET)
	 public String applyjob(@RequestParam(value="user") String user,@RequestParam(value="job") String jobid,HttpSession session) {
		 
		 InterviewDetail interview = new InterviewDetail();
		 
		 Candidate candidate = outerCandidate.findById(user);
		 
		 Jobs job = jobdao.findById(jobid);
		  
		 candidateList.add(candidate);
		 
		 job.setCandidate(candidateList);
		 
		 interview.setStatus("applied");
		 interview.setDate(new Date());
		 interview.setJob(job);
		 interview.setCandidate(candidate);
		 
		 interviewdetaildao.addDetails(interview);
		 System.out.println("data inserted...Applied for job");
		 return "sucess";
	 }
	 @RequestMapping(value="viewstatus")
	 public ModelAndView status(@RequestParam("id") String user) {
		 Candidate candidate = outerCandidate.findById(user);
		 int candidate_id = candidate.getCandidateId();
		 List<InterviewDetail> statusL = interviewdetaildao.getStatus(candidate_id);
		 List<Jobs> jobids = interviewdetaildao.getJobId(candidate_id);
		 
		 System.out.println(statusL.get(0).getStatus());
		 
	
		 List<Jobs> joball = new ArrayList<Jobs>();
		 
		 for(int i=0;i<jobids.size();i++) {
			 Jobs job = jobids.get(i);
			 
			 String status = statusL.get(i).getStatus();
			 job.setTemp(status);
			joball.add(job);
		 }
		 ModelAndView mv = new ModelAndView("viewstatus");
		 mv.addObject("job", joball);
		 return mv;
	 }
}
