package com.virtusa.recruitment.login.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class Login {
    @Id
    @Column(name="userId")
	private int userId;
    @Column(name="password")
	private String password;
	
	public Login() {
		super();
		this.userId = 0;
		this.password = null;
	}
	public Login(int userId, String password) {
		super();
		this.userId = userId;
		this.password = password;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	



}
