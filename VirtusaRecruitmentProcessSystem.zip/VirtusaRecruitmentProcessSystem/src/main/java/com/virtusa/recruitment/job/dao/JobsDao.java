package com.virtusa.recruitment.job.dao;

import java.util.List;

import com.virtusa.recruitment.job.model.Jobs;

public interface JobsDao {

	public List<Jobs> getJoblist();
	public Jobs findById (String job_id);
	public void update(Jobs job);
	public void insertJob (Jobs job);
	public void deleteById(String job_id);
}
