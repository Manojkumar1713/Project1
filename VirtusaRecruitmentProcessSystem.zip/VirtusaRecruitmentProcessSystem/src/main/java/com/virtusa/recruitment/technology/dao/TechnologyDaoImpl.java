package com.virtusa.recruitment.technology.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

import org.springframework.stereotype.Service;

import com.virtusa.recruitment.technology.model.Technology;
@Service
public class TechnologyDaoImpl implements TechnologyDao {

	public void addtechnology(Technology technology) {
		Session session = new Configuration().addAnnotatedClass(Technology.class).configure().buildSessionFactory().openSession();
		session.beginTransaction();
		session.save(technology);
		session.getTransaction().commit();
		session.close();
	}

	public void deleteTechnology(int techid) {
		// TODO Auto-generated method stub
		
	}

	public List<Technology> viewall() {
		Session session = new Configuration().addAnnotatedClass(Technology.class).configure().buildSessionFactory().openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Technology");
		List list = query.getResultList();
		
		return list;
	}

	public Technology findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
