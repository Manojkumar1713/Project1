package com.virtusa.recruitment.accomodation.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.virtusa.recruitment.accomodation.model.AccomodationDetail;


	@Repository
	public class AccomodationDaoImpl implements AccomodationDao{
	   /*creating session object */
		
	    
		public List<AccomodationDetail> viewAccomodation() {
			Session session = new Configuration().addAnnotatedClass(AccomodationDetail.class).configure().buildSessionFactory().openSession();
			Query query = session.createQuery("from AccomodationDetail");
			List<AccomodationDetail> list = query.getResultList();
			session.close();
			return list;

		}
		public void addAccomodation(AccomodationDetail accomodationdetail) {
			Session session = new Configuration().addAnnotatedClass(AccomodationDetail.class).configure().buildSessionFactory().openSession();
			session.beginTransaction();
			session.save(accomodationdetail);
			session.getTransaction().commit();
			session.close();


		}
		public void deleteById(int id) {

			Session session = new Configuration().addAnnotatedClass(AccomodationDetail.class).configure().buildSessionFactory().openSession();
			AccomodationDetail accomodationid = (AccomodationDetail) session.get(AccomodationDetail.class,id);
			session.beginTransaction();
			session.delete(accomodationid);
			session.getTransaction().commit();
			session.close();

		}



	}


