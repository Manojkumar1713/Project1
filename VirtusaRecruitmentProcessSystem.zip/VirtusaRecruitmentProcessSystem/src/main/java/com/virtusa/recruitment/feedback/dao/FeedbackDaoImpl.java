package com.virtusa.recruitment.feedback.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.virtusa.recruitment.feedback.model.Feedback;
@Repository
public class FeedbackDaoImpl implements FeedbackDao{

	public void add(Feedback feedback) {
		// TODO Auto-generated method stub
		Session session=new Configuration().addAnnotatedClass(Feedback.class).configure().buildSessionFactory().openSession();
		session.beginTransaction();
		session.save(feedback);
		session.getTransaction().commit();
		session.close();
		
	}

	public void update(Feedback feedback) {
		
		Session session=new Configuration().addAnnotatedClass(Feedback.class).configure().buildSessionFactory().openSession();	
		session.beginTransaction();
		session.update(feedback);
		session.getTransaction().commit();
		session.close();
	}

	public Feedback view(String feedbackId) {
		int feedbacid=Integer.parseInt(feedbackId);
		Session session=new Configuration().addAnnotatedClass(Feedback.class).configure().buildSessionFactory().openSession();
		Feedback feedback=session.get(Feedback.class,feedbacid);
		session.getTransaction().commit();
		return feedback;
		
	}

	public List<Feedback> getAllFeedbacks() {

		Session session=new Configuration().addAnnotatedClass(Feedback.class).configure().buildSessionFactory().openSession();		
		session.beginTransaction();
		List<Feedback> feeds=session.createQuery("from Feedback").list();
		session.getTransaction().commit();
		session.close();
		
		return feeds;
	}

	public void delete(String feedbackId) {	
		Session session=new Configuration().addAnnotatedClass(Feedback.class).configure().buildSessionFactory().openSession();		
		session.beginTransaction();
		int feedbackid=Integer.parseInt(feedbackId);
		Feedback feed=session.get(Feedback.class, feedbackid);
		session.delete(feed);
		session.getTransaction().commit();
        session.close();		
		
		
	}

	public Feedback findById(int id) {
		Session session=new Configuration().addAnnotatedClass(Feedback.class).configure().buildSessionFactory().openSession();		
		session.beginTransaction();
		Feedback fe = session.get(Feedback.class, id);
		session.close();
		return fe;
	}
	
}
