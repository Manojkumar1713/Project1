package com.virtusa.recruitment.interview.dao;


import java.util.List;

import com.virtusa.recruitment.interview.model.InterviewDetail;
import com.virtusa.recruitment.job.model.Jobs;

public interface InterviewDetailDao {
	public void addDetails(InterviewDetail interview);
	public void updateStatusInterview(InterviewDetail interview);
	public InterviewDetail findById(int employeeId);
	public List<InterviewDetail> getall();
	public void deleteById(String interviewId);
	public String checkApplication(int candidate_id,int job_id);
	public List<InterviewDetail> getStatus(int id);
	public List<Jobs> getJobId(int id);
	public InterviewDetail getobj(int cid,int jid);
}
