package com.virtusa.recruitment.technology.dao;

import java.util.List;

import com.virtusa.recruitment.technology.model.Technology;

public interface TechnologyDao {
	
	public void addtechnology(Technology technology);
	public void deleteTechnology(int techid);
	public List<Technology> viewall();
	public Technology findById(int id);

}
