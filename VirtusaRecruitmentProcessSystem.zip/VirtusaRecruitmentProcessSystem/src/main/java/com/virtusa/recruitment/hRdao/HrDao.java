
package com.virtusa.recruitment.hRdao;

import java.util.List;

import com.virtusa.recruitment.hR.Hr;



public interface HrDao {
	public void add(Hr hr);
    public List<Hr>  viewAllHrs();
    public List<Hr> viewAllTechHead();
    public void update(int hrname);
	public Hr find(int id);
	public void updateHR(Hr hr);
	public List view();
}
