
package com.virtusa.recruitment.hRdao;

import java.util.List;

import com.virtusa.recruitment.hR.Hr;



public interface HrDao {
	public void add(Hr hr);
    public List<Hr>  viewAllHrs();
}
