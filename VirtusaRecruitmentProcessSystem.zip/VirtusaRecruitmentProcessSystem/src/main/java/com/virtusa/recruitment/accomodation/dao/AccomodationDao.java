package com.virtusa.recruitment.accomodation.dao;

import java.util.List;

import com.virtusa.recruitment.accomodation.model.AccomodationDetail;



public interface AccomodationDao {
	public List<AccomodationDetail> viewAccomodation();
	public void addAccomodation(AccomodationDetail accomodationdetail);
	public void deleteById(int id);

}
