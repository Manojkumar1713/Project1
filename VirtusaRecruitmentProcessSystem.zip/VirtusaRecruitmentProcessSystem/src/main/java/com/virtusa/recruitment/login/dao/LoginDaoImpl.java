package com.virtusa.recruitment.login.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.virtusa.recruitment.hR.Hr;
import com.virtusa.recruitment.login.models.Login;
import com.virtusa.recruitment.outercandidate.model.Candidate;

@Repository
public class LoginDaoImpl implements LoginDAO
{
	public boolean findbyId(Candidate login) {

		Session session = new Configuration().addAnnotatedClass(Login.class).configure().buildSessionFactory().openSession();
		session.beginTransaction();
		
		String hql= "SELECT password FROM Candidate WHERE emailId = :uid";
		Query query = session.createQuery(hql); 
		query.setParameter("uid",login.getEmailId());// value from ui
		List list =query.getResultList();
		if(!(list.isEmpty()))
		{
			if(login.getPassword().equals(list.get(0)))
			{
				return true;
			}
		
		else
				return false;
		}
		else
			return false;
	    }
	public boolean findbyHr(Hr login) {

		Session session = new Configuration().addAnnotatedClass(Hr.class).configure().buildSessionFactory().openSession();
		session.beginTransaction();
		
		String hql= "SELECT password FROM Hr WHERE hrId = :uid";
		Query query = session.createQuery(hql); 
		query.setParameter("uid",login.getHrId());// value from ui
		List list =query.getResultList();
		if(!(list.isEmpty()))
		{
			if(login.getPassword().equals(list.get(0)))
			{
				return true;
			}
		
		else
				return false;
		}
		else
			return false;
	    }
}
