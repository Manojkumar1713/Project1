package com.virtusa.recruitment.outercandidate.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.virtusa.recruitment.job.model.Jobs;

@Entity
public class Candidate {
	
	
    @Id
    @GeneratedValue(strategy=GenerationType.TABLE)
	private int candidateId;
	private String candidateName;
	private String phNo;
	@Column(unique=true)
	private String emailId;
	private String DOB;
	private String password;

	@Embedded
	private CandidateExperience candidateExperience;
	@Embedded
	private CandidateAddress candidateAddress;
	@Embedded
	private CandidateEducationDetails candidateEducationDetails;
	
	
	public Candidate() {

	}
	
	public Candidate(int candidateId, String candidateName, String phNo, String emailId, String dOB, String password,
			 CandidateExperience candidateExperience, CandidateAddress candidateAddress,
			CandidateEducationDetails candidateEducationDetails) {
		super();
		this.candidateId = candidateId;
		this.candidateName = candidateName;
		this.phNo = phNo;
		this.emailId = emailId;
		this.DOB = dOB;
		this.password = password;

		this.candidateExperience = candidateExperience;
		this.candidateAddress = candidateAddress;
		this.candidateEducationDetails = candidateEducationDetails;
	}

	public int getCandidateId() {
		return candidateId;
	}


	public void setCandidateId(int candidateId) {
		this.candidateId = candidateId;
	}


	public String getCandidateName() {
		return candidateName;
	}


	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}


	public String getPhNo() {
		return phNo;
	}


	public void setPhNo(String phNo) {
		this.phNo = phNo;
	}


	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	public CandidateExperience getCandidateExperience() {
		return candidateExperience;
	}


	public void setCandidateExperience(CandidateExperience candidateExperience) {
		this.candidateExperience = candidateExperience;
	}


	public CandidateAddress getCandidateAddress() {
		return candidateAddress;
	}


	public void setCandidateAddress(CandidateAddress candidateAddress) {
		this.candidateAddress = candidateAddress;
	}


	public CandidateEducationDetails getCandidateEducationDetails() {
		return candidateEducationDetails;
	}


	public void setCandidateEducationDetails(CandidateEducationDetails candidateEducationDetails) {
		this.candidateEducationDetails = candidateEducationDetails;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String DOB) {
		this.DOB = DOB;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "Candidate [candidateId=" + candidateId + ", candidateName=" + candidateName + ", phNo=" + phNo
				+ ", emailId=" + emailId + ", DOB=" + DOB + ", password=" + password + ", status=" 
				+ ", candidateExperience=" + candidateExperience + ", candidateAddress=" + candidateAddress
				+ ", candidateEducationDetails=" + candidateEducationDetails + "]";
	}

	

	

}
