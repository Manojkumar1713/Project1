package com.virtusa.recruitment.login.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.recruitment.hR.Hr;
import com.virtusa.recruitment.hRdao.DaoImpl;
import com.virtusa.recruitment.login.dao.LoginDAO;
import com.virtusa.recruitment.login.dao.LoginDaoImpl;
import com.virtusa.recruitment.login.models.Login;
import com.virtusa.recruitment.outercandidate.dao.OuterCandidateDaoImpl;
import com.virtusa.recruitment.outercandidate.model.Candidate;

@Controller
public class LoginController
{
	@Autowired
	private LoginDaoImpl logindoa;
	@Autowired
	private OuterCandidateDaoImpl outerCandidate ;
	@Autowired
	DaoImpl daiImpl;

	@RequestMapping(value="login",method=RequestMethod.GET)
	public ModelAndView Authenticate()
	{
		return new ModelAndView("login","emplogin",new Candidate());
		
		
	}
	@RequestMapping(value="login",method=RequestMethod.POST)
	public ModelAndView verfication(@ModelAttribute("login")  Candidate outercand,HttpSession session)
	{ 
		
		if(outercand.getEmailId().equals("admin") && outercand.getPassword().equals("admin")) {
		ModelAndView mvad = new ModelAndView("adminhome");
		session.setAttribute("admin", outercand.getEmailId());
		return mvad;
		}
		
		
		
		Candidate outercandidate = outerCandidate.findById(outercand.getEmailId());
		boolean var=logindoa.findbyId(outercand);
		if(var)
		{
			ModelAndView mav = new ModelAndView("sucess");
			session.setAttribute("users",outercandidate.getCandidateName());
			session.setAttribute("user",outercand.getEmailId());
			return mav;
		}
		else
		{
			ModelAndView mv = new ModelAndView("success");
			mv.addObject("data","wrong password or userid");
			return mv;
		}
		
	}
	@RequestMapping(value="logout")
	public ModelAndView logout(HttpServletRequest request)
	{
		HttpSession session= request.getSession(false);
		if(session != null)
		{
			session.invalidate();
		}
		ModelAndView mv = new ModelAndView("loginjs");
		return mv;
	}
	
	@RequestMapping(value="hrlogin",method=RequestMethod.GET)
	public ModelAndView AuthenticateHr()
	{
		return new ModelAndView("hrlogin","hrlogin",new Hr());
		
		
	}
	
	
	@RequestMapping(value="hrlogin",method=RequestMethod.POST)
	public ModelAndView verfication(@ModelAttribute("login")  Hr hr,HttpSession session)
	{ 
	
		
		Hr hrs = daiImpl.find(hr.getHrId());
		boolean var=logindoa.findbyHr(hr);
		if(var)
		{
			ModelAndView mav = new ModelAndView("hrsucess");
			session.setAttribute("users",hrs.getJob());
			session.setAttribute("user",hr.getName());
			return mav;
		}
		else
		{
			ModelAndView mv = new ModelAndView("success");
			mv.addObject("data","wrong password or userid");
			return mv;
		}
		
	}
	
	
}
