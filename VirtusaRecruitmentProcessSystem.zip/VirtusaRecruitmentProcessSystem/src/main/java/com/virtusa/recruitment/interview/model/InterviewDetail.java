package com.virtusa.recruitment.interview.model;



import java.util.Date;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToOne;

import com.virtusa.recruitment.feedback.model.Feedback;
import com.virtusa.recruitment.job.model.Jobs;
import com.virtusa.recruitment.outercandidate.model.Candidate;

@Entity
public class InterviewDetail {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int interviewId;

	private Date date;
	@OneToOne(cascade=CascadeType.ALL)
	private Jobs job;
	private String status;
	@OneToOne(cascade=CascadeType.ALL)
	private Candidate candidate;
	@OneToOne(cascade=CascadeType.ALL)
	private Feedback feedback;
	
	
	
	
	public Candidate getCandidate() {
		return candidate;
	}
	public void setCandidate(Candidate candidate) {
		this.candidate = candidate;
	}
	public int getInterviewId() {
		return interviewId;
	}
	public Feedback getFeedback() {
		return feedback;
	}
	public void setFeedback(Feedback feedback) {
		this.feedback = feedback;
	}
	public void setInterviewId(int interviewId) {
		this.interviewId = interviewId;
	}

	public Date getDate() {
		return date;
	}
	public void setDate(Date date2) {
		this.date = date2;
	}
	
	
	public InterviewDetail() {
		super();
	}
	
	
	public Jobs getJob() {
		return job;
	}
	public void setJob(Jobs job) {
		this.job = job;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public InterviewDetail(int interviewId, Date date,
			String status) {
		super();
		this.interviewId = interviewId;
		this.date = date;
		this.status = status;
		
		

	}
	
}
