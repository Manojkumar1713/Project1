package com.virtusa.recruitment.hRdao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.virtusa.recruitment.hR.Hr;



@Repository
public class DaoImpl implements HrDao{

	public void add(Hr hr) {

		SessionFactory sessionFactory =new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.save(hr);
		session.getTransaction().commit();
		session.close();
		
	}

	public List<Hr> viewAllHrs() {
		SessionFactory sessionFactory =new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Query q=session.createQuery(" from Hr where status=0 and designation=:h");
		q.setParameter("h", "Hr");
		List<Hr> lists = q.getResultList();
		session.getTransaction().commit();
		return lists;
	}
	
	
	public List<Hr> viewAllTechHead() {
		SessionFactory sessionFactory =new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Query q=session.createQuery(" from Hr where status=0 and designation=:h");
		q.setParameter("h", "TechnicalHead");
		List<Hr> lists = q.getResultList();
		session.getTransaction().commit();
		return lists;
	}
	
	public void update(int hrname)
	{
		SessionFactory sessionFactory =new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Query query=session.createQuery("update Hr set status=1 where hrId=:hrnames");
		query.setParameter("hrnames", hrname);
		query.executeUpdate();
		session.getTransaction().commit();
		session.close();
	}
	public Hr find(int id)
	{
		Session s = new Configuration().addAnnotatedClass(Hr.class).configure().buildSessionFactory().openSession();
		s.beginTransaction();
		Hr r = s.get(Hr.class, id);
		s.getTransaction().commit();
		s.close();
		return r;
	}
	public void updateHR(Hr hr)
	{
		Session s = new Configuration().addAnnotatedClass(Hr.class).configure().buildSessionFactory().openSession();
		s.beginTransaction();
		s.update(hr);
		s.getTransaction().commit();
		s.close();
	}
	public List view() {
		Session s = new Configuration().addAnnotatedClass(Hr.class).configure().buildSessionFactory().openSession();
		s.beginTransaction();
		Query q = s.createQuery("from Hr");
		List<Hr> hr = q.getResultList();
		s.getTransaction().commit();
		s.close();
		return hr;
	}
}
