package com.virtusa.recruitment.feedback.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

//import com.virtusa.recruitment.technology.model.Technology;
@Entity
public class Feedback {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int feedbackId;
//	@OneToMany(cascade=CascadeType.ALL)
//	private List<String> technologyFeedback;
//	private String hrFeedback;
//	public int getFeedbackId() {
//		return feedbackId;
//	}
//	public void setFeedbackId(int feedbackId) {
//		this.feedbackId = feedbackId;
//	}
//	public List<String> getTechnologyFeedback() {
//		return technologyFeedback;
//	}
//	public void setTechnologyFeedback(List<String> technologyFeedback) {
//		this.technologyFeedback = technologyFeedback;
//	}
//	public String getHrFeedback() {
//		return hrFeedback;
//	}
//	public void setHrFeedback(String hrFeedback) {
//		this.hrFeedback = hrFeedback;
//	}
//	public Feedback() {
//		super();
//	}
//	public Feedback(int feedbackId, List<String> technologyFeedback, String hrFeedback) {
//		super();
//		this.feedbackId = feedbackId;
//		this.technologyFeedback = technologyFeedback;
//		this.hrFeedback = hrFeedback;
//	}
//
//

}
