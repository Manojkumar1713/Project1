package com.virtusa.recruitment.technology.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.recruitment.feedback.dao.FeedbackDaoImpl;
import com.virtusa.recruitment.feedback.model.Feedback;
import com.virtusa.recruitment.interview.dao.InterviewDetailDao;
import com.virtusa.recruitment.interview.dao.InterviewDetailDaoImpl;
import com.virtusa.recruitment.interview.model.InterviewDetail;
import com.virtusa.recruitment.job.dao.JobsDaoImpl;
import com.virtusa.recruitment.job.model.Jobs;
import com.virtusa.recruitment.outercandidate.dao.OuterCandidateDaoImpl;
import com.virtusa.recruitment.outercandidate.model.Candidate;
import com.virtusa.recruitment.technology.dao.TechnologyDaoImpl;
import com.virtusa.recruitment.technology.model.Technology;

@Controller
public class TechnologyController {

	@Autowired
	TechnologyDaoImpl technologydaoimpl;
	@Autowired
	public InterviewDetailDao interviewdetaildao;
	@Autowired
	public FeedbackDaoImpl feedimpl;
	@Autowired
	JobsDaoImpl jobsdaoimpl;
	 @Autowired
	 InterviewDetailDaoImpl interviewdetaildaoimpl;
	 @Autowired
	 OuterCandidateDaoImpl outercandidateimpl;
	 @Autowired
	FeedbackDaoImpl feedbackdao;
		
	
	@RequestMapping(value="tech", method=RequestMethod.GET)
	public ModelAndView getadd() {
		
		return new ModelAndView("addtech","techcommand",new Technology());
	}
	@RequestMapping(value="tech",method=RequestMethod.POST)
	public ModelAndView add(@ModelAttribute("tech") Technology technology)
	{
		technologydaoimpl.addtechnology(technology);
		return null;
	}
	@RequestMapping(value="viewtech")
	public ModelAndView viewall()
	{
		ModelAndView mav = new ModelAndView("viewtech");
		List list=technologydaoimpl.viewall();
		mav.addObject("list",list);
		return mav;
	}
	@RequestMapping(value="gettech",method=RequestMethod.POST)
	public ModelAndView getlist(@RequestParam("tech") String tech,@RequestParam("candid") int cid,@RequestParam("jobid") int jid,@RequestParam("hrfeedback") String hrfbd,@RequestParam("designation") String designation)
	{
		List<Technology> listTech = new ArrayList<Technology>();
		String[] technologies = tech.split(",");
		for(int i=0;i<technologies.length;i++) {
			Technology technolo = new Technology();
			technolo.setTechonoglyName(technologies[i]);
			listTech.add(technolo);
		}
		Feedback feed = new Feedback();
		feed.setHrFeedback(hrfbd);
		feed.setTechnologyFeedback(listTech);
		feedimpl.add(feed);
		InterviewDetail interview = interviewdetaildao.getobj(cid, jid);
		interview.setFeedback(feed);
		interviewdetaildao.updateStatusInterview(interview);
		System.out.println("data added");
		List<Integer> candIds = interviewdetaildaoimpl.findCandidateById(jid);
		List<Candidate> jobcand = new ArrayList<Candidate>();
		
		for(int i=0;i<candIds.size();i++)
	    {
			Candidate cand = outercandidateimpl.Candfindbyid(candIds.get(i)); 
			jobcand.add(cand);
		}
		String ids= String.valueOf(jid);
		Jobs job = jobsdaoimpl.findById(ids);
		ModelAndView mv = new ModelAndView("viewlistjchr");
		List list=technologydaoimpl.viewall();
		mv.addObject("tech",list);
		mv.addObject("jobcandlist",jobcand);
		mv.addObject("job",job);
		return mv;
	}
	@RequestMapping(value="updatestatus",method=RequestMethod.POST)
	 public ModelAndView updatestatus(@RequestParam("status") String status,@RequestParam("jobid") int jid,@RequestParam("candid") int cid) {
		System.out.println(cid+" "+jid+" "+status);
		 interviewdetaildao.update(cid, jid, status);
		 List<Integer> candIds = interviewdetaildaoimpl.findCandidateId(jid);
			List<Integer> feedIds = interviewdetaildaoimpl.feedbackList(jid);
			List<Feedback> FeedCand = new ArrayList<Feedback>();
			List<Candidate> jobcand = new ArrayList<Candidate>();
			
			for(int j=0;j<feedIds.size();j++) {
				Feedback feedback = feedbackdao.findById(feedIds.get(j));
				FeedCand.add(feedback);
			}
			
			
			for(int i=0;i<candIds.size();i++)
		    {
				Candidate cand = outercandidateimpl.Candfindbyid(candIds.get(i));
				cand.setFeedtemp(FeedCand.get(i).getHrFeedback());
				jobcand.add(cand);
			}
			
			
			String ids= String.valueOf(jid);
			Jobs job = jobsdaoimpl.findById(ids);
			ModelAndView mv = new ModelAndView("viewlisthrf");
	
			mv.addObject("jobcandlist",jobcand);
			mv.addObject("job",job);
			return mv;
		
	 }
	
}
