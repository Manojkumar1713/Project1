//package com.virtusa.recruitment.technology.controller;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.servlet.ModelAndView;
//
//import com.virtusa.recruitment.feedback.dao.FeedbackDaoImpl;
//import com.virtusa.recruitment.feedback.model.Feedback;
//import com.virtusa.recruitment.interview.dao.InterviewDetailDao;
//import com.virtusa.recruitment.interview.model.InterviewDetail;
//import com.virtusa.recruitment.job.model.Jobs;
//import com.virtusa.recruitment.technology.dao.TechnologyDaoImpl;
//import com.virtusa.recruitment.technology.model.Technology;
//
//@Controller
//public class TechnologyController {
//
//	@Autowired
//	TechnologyDaoImpl technologydaoimpl;
//	@Autowired
//	public InterviewDetailDao interviewdetaildao;
//	@Autowired
//	public FeedbackDaoImpl feedimpl;
//	
//	
//	@RequestMapping(value="tech", method=RequestMethod.GET)
//	public ModelAndView getadd() {
//		
//		return new ModelAndView("addtech","techcommand",new Technology());
//	}
//	@RequestMapping(value="tech",method=RequestMethod.POST)
//	public ModelAndView add(@ModelAttribute("tech") Technology technology)
//	{
//		technologydaoimpl.addtechnology(technology);
//		return null;
//	}
//	@RequestMapping(value="viewtech")
//	public ModelAndView viewall()
//	{
//		ModelAndView mav = new ModelAndView("viewtech");
//		List list=technologydaoimpl.viewall();
//		mav.addObject("list",list);
//		return mav;
//	}
//	@RequestMapping(value="gettech",method=RequestMethod.POST)
//	public ModelAndView getlist(@RequestParam("tech") List<String> tech,@RequestParam("candid") int cid,@RequestParam("jobid") int jid,@RequestParam("hrfeedback") String hrfbd)
//	{
//		Feedback feedback = new Feedback();
//		feedback.setHrFeedback(hrfbd);
//		feedback.setTechnologyFeedback(tech);
//		feedimpl.add(feedback);
//		/*InterviewDetail interview = interviewdetaildao.getobj(cid, jid);
//		interview.setFeedback(feedback);
//		interviewdetaildao.updateStatusInterview(interview);*/
//		return null;
//	}
//	
//}
