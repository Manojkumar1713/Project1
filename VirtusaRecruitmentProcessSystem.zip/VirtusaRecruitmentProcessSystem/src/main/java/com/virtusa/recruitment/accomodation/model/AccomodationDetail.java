package com.virtusa.recruitment.accomodation.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class AccomodationDetail {
	@Id
	@GeneratedValue(strategy=GenerationType.TABLE)
	private int accomodationId;
	private String accomodationName;
	private String accomodationFeedback;
	private String accomodationRatings;
	private String accomodationContactNo;
	private String accomodationlocation;
	private int outercandidateid;
	
	public AccomodationDetail() {
		super();
	}

	
	public AccomodationDetail(int accomodationId, String accomodationName, String accomodationFeedback,
			String accomodationRatings, String accomodationContactNo, String accomodationlocation) {
		super();
		this.accomodationId = accomodationId;
		this.accomodationName = accomodationName;
		this.accomodationFeedback = accomodationFeedback;
		this.accomodationRatings = accomodationRatings;
		this.accomodationContactNo = accomodationContactNo;
		this.accomodationlocation = accomodationlocation;
	}


	public int getAccomodationId() {
		return accomodationId;
	}


	public void setAccomodationId(int accomodationId) {
		this.accomodationId = accomodationId;
	}


	public String getAccomodationName() {
		return accomodationName;
	}


	public void setAccomodationName(String accomodationName) {
		this.accomodationName = accomodationName;
	}


	public String getAccomodationFeedback() {
		return accomodationFeedback;
	}


	public void setAccomodationFeedback(String accomodationFeedback) {
		this.accomodationFeedback = accomodationFeedback;
	}


	public String getAccomodationRatings() {
		return accomodationRatings;
	}


	public void setAccomodationRatings(String accomodationRatings) {
		this.accomodationRatings = accomodationRatings;
	}


	public String getAccomodationContactNo() {
		return accomodationContactNo;
	}


	public void setAccomodationContactNo(String accomodationContactNo) {
		this.accomodationContactNo = accomodationContactNo;
	}


	public String getAccomodationlocation() {
		return accomodationlocation;
	}


	public void setAccomodationlocation(String accomodationlocation) {
		this.accomodationlocation = accomodationlocation;
	}
	
	

}

