package com.virtusa.recruitment.login.dao;

import java.util.List;

import com.virtusa.recruitment.login.models.Login;
import com.virtusa.recruitment.outercandidate.model.Candidate;

public interface LoginDAO  {
	
  boolean findbyId(Candidate login);
	

}
