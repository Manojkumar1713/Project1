package com.virtusa.recruitment.outercandidate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.recruitment.job.dao.JobsDaoImpl;
import com.virtusa.recruitment.job.model.Jobs;
import com.virtusa.recruitment.login.dao.LoginDaoImpl;
import com.virtusa.recruitment.outercandidate.dao.OuterCandidateDao;
import com.virtusa.recruitment.outercandidate.dao.OuterCandidateDaoImpl;
import com.virtusa.recruitment.outercandidate.model.Candidate;



@Controller
public class OuterCandidateController {
	
	@Autowired
	private OuterCandidateDaoImpl outerCandidate ;
	
	
	
	@RequestMapping(value="reg",method=RequestMethod.GET)
	public ModelAndView setRegistration()
	{
		
		return new ModelAndView("Registration","emp",new Candidate());
		
	}
	@RequestMapping(value="reg",method=RequestMethod.POST)
	public String getRegistration(@ModelAttribute("Registration") Candidate registration) {
		
		
		outerCandidate.addOuterCandidate(registration);
		return "redirect";
	}

	@RequestMapping(value="updateuser", method=RequestMethod.GET)
	public ModelAndView update(@RequestParam(value="id") String id){
		Candidate outercandidate = outerCandidate.findById(id);
		//System.out.println(job.getCategory());
		return new ModelAndView("edituser","update",outercandidate);
	}
	@RequestMapping(value="updateuser",method=RequestMethod.POST)
	public ModelAndView updation(@ModelAttribute("update") Candidate outercandidate)
	{
		String email = outercandidate.getEmailId();
		outerCandidate.updateOuterCandidate(outercandidate);
		List list = outerCandidate.viewUser(email);
		ModelAndView mv = new ModelAndView("viewcandidate");
		mv.addObject("list", list);
		return mv;
		
	}
	@RequestMapping(value="viewcand")
	public ModelAndView geview() {
		List list = outerCandidate.getCandidatelist();
		ModelAndView mv = new ModelAndView("viewCandidate");
		mv.addObject("list", list);
		return mv;
}
	@RequestMapping(value="deleteById",method=RequestMethod.GET)
public ModelAndView deleteById(@RequestParam("candidateId")int theid)
{
		int a=Integer.valueOf(theid);
	 outerCandidate.deleteById(a);
	 List list = outerCandidate.getCandidatelist();
		ModelAndView mv = new ModelAndView("viewCandidate");
		mv.addObject("list", list);
		return mv;
	 
}
	
	@RequestMapping(value="viewprofile")
	public ModelAndView viewprofile(@RequestParam(value="id") String id) {
		List list = outerCandidate.viewUser(id);
		ModelAndView mv = new ModelAndView("viewcandidate");
		mv.addObject("list", list);
		return mv;
}
	
}
