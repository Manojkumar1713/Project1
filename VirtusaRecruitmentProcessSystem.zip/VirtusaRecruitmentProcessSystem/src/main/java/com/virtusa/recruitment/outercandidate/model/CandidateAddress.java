package com.virtusa.recruitment.outercandidate.model;

import javax.persistence.Embeddable;

@Embeddable
public class CandidateAddress {
	
	private String streetName;
	private String doorNo;
	private String locality;
	private String city;
	private String State;
	public CandidateAddress() {
		super();
	}
	
	public CandidateAddress(String streetName, String doorNo, String locality, String city, String state) {
		super();
		this.streetName = streetName;
		this.doorNo = doorNo;
		this.locality = locality;
		this.city = city;
		this.State = state;
	}

	

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getDoorNo() {
		return doorNo;
	}

	public void setDoorNo(String doorNo) {
		this.doorNo = doorNo;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}
	

}
